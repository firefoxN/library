-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 06 2017 г., 14:16
-- Версия сервера: 5.7.17-0ubuntu0.16.04.1
-- Версия PHP: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `library`
--

-- --------------------------------------------------------

--
-- Структура таблицы `author`
--

CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `short_description` text,
  `full_description` text,
  `preview` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `author`
--

INSERT INTO `author` (`id`, `name`, `slug`, `short_description`, `full_description`, `preview`, `created_at`, `updated_at`) VALUES
(3, 'Анджей Сапковский', 'andzhey-sapkovskiy', 'Польский писатель-фантаст и публицист, автор популярной фэнтези-саги «Ведьмак». Произведения Сапковского изданы на чешском, русском, немецком, испанском, финском, литовском, французском, английском, португальском, болгарском, итальянском, шведском, сербском и украинском языках. По заявлениям издателей, Сапковский входит в пятёрку самых издаваемых авторов Польши. Сам же писатель, как правило, не распространяется о тиражах своих книг.', 'Польский писатель-фантаст и публицист, автор популярной фэнтези-саги «Ведьмак». Произведения Сапковского изданы на чешском, русском, немецком, испанском, финском, литовском, французском, английском, португальском, болгарском, итальянском, шведском, сербском и украинском языках. По заявлениям издателей, Сапковский входит в пятёрку самых издаваемых авторов Польши. Сам же писатель, как правило, не распространяется о тиражах своих книг.', 'sapek_big_1488794847.png', 1488626121, 1488794847);

-- --------------------------------------------------------

--
-- Структура таблицы `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `short_description` text,
  `full_description` text,
  `author_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `preview` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `epub` varchar(255) DEFAULT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `txt` varchar(255) DEFAULT NULL,
  `fb2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `book`
--

INSERT INTO `book` (`id`, `name`, `slug`, `short_description`, `full_description`, `author_id`, `category_id`, `preview`, `created_at`, `updated_at`, `pdf`, `epub`, `doc`, `txt`, `fb2`) VALUES
(1, 'Последнее желание', 'poslednee-zhelanie', '«Последнее желание» (польск. Ostatnie życzenie) — сборник рассказов писателя Анджея Сапковского в жанре фэнтези, объединённых общим персонажем — ведьмаком Геральтом из Ривии.', '«Последнее желание» (польск. Ostatnie życzenie) — сборник рассказов писателя Анджея Сапковского в жанре фэнтези, объединённых общим персонажем — ведьмаком Геральтом из Ривии. Это первое произведение из цикла «Ведьмак» как по хронологии, так и по времени написания. От первого издания в виде книги «Ведьмак» «Последнее желание» отличается связующей серией интерлюдий «Глас рассудка».', 3, 1, 'последнее_желание_1488744528.jpg', 1488640744, 1488744528, NULL, NULL, NULL, '34379_1488744254.txt', NULL),
(2, 'Меч Предназначения', 'mech-prednaznacheniya', 'сборник рассказов Анджея Сапковского в жанре фэнтези, объединённых общим персонажем — ведьмаком Геральтом из Ривии. Это второе произведение из цикла «Ведьмак»', 'сборник рассказов Анджея Сапковского в жанре фэнтези, объединённых общим персонажем — ведьмаком Геральтом из Ривии. Это второе произведение из цикла «Ведьмак» как по хронологии, так и по времени написания. В этой части Геральт впервые встречает Цири и находит своё предназначение.', 3, 1, 'меч_предназначения_1488745908.jpg', 1488646381, 1488745908, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `short_description` text,
  `full_description` text,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `name`, `slug`, `parent_id`, `short_description`, `full_description`, `created_at`, `updated_at`) VALUES
(1, 'Фэнтези', 'pervaya-kategoriya', 0, '', 'Первая очень интересная категория', 1488632890, 1488745944),
(2, 'вторая категория', 'vtoraya-kategoriya', 0, '', '', 1488634355, 1488634355),
(3, 'категория 1.1', 'kategoriya-11', 1, '', '', 1488634413, 1488634413),
(4, 'категория 1.2', 'kategoriya-12', 1, '', '', 1488634430, 1488634430),
(5, 'категория 1.1.1', 'kategoriya-111', 3, '', '', 1488634448, 1488634448),
(6, 'категория 1.1.2', 'kategoriya-112', 3, '', '', 1488634459, 1488634459),
(7, 'категория 2.1', 'kategoriya-21', 2, '', '', 1488634489, 1488634489);

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1488534532),
('m170303_093456_create_book_table', 1488534536),
('m170303_095020_create_category_table', 1488534812),
('m170303_095403_create_author_table', 1488534991),
('m170303_100047_change_book_table', 1488535328),
('m170303_100240_link_category_book_tables', 1488535854),
('m170303_101107_link_author_book_tables', 1488536082),
('m170304_165646_alter_book_table', 1488646851);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx-book-category_id` (`category_id`),
  ADD KEY `idx-book-author_id` (`author_id`);

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Индексы таблицы `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `author`
--
ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `fk-book-author_id` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-book-category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
